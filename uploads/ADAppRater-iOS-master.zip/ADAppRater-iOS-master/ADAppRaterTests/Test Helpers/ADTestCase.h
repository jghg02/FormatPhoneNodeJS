//
//  ADTestCase.h
//  ADAppRater Demo
//
//  Created by Amir Shavit on 6/16/15.
//  Copyright (c) 2015 Autodesk. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <OCMock/OCMock.h>
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#import "ADMockingHelpers.h"

@interface ADTestCase : XCTestCase

@end
