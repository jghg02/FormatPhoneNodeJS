//
//  ADAppRater.h
//  ADAppRater
//
//  Created by Amir Shavit on 7/21/15.
//  Copyright (c) 2015 Autodesk. All rights reserved.
//

#import "ADAppRater.h"

@interface ADAppRater ()

+ (void)AR_logConsole:(NSString*)message;

@end
