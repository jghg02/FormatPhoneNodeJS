//
//  AppDelegate.h
//  ADAppRater Demo
//
//  Created by Amir Shavit on 8/3/15.
//  Copyright (c) 2015 Autodesk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

