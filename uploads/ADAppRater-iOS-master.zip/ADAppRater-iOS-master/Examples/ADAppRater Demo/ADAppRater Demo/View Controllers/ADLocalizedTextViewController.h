//
//  ADLocalizedTextViewController.h
//  ADAppRater Demo
//
//  Created by Amir Shavit on 9/10/15.
//  Copyright © 2015 Autodesk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ADAppRater/ADAppRater.h>

@interface ADLocalizedTextViewController : UIViewController

- (IBAction)pressedStartFlowButton:(UIButton *)sender;

@end
